<?php
define('SMTP_HOST', getenv('SMTP_HOST') ?: 'smtp.gmail.com');
define('SMTP_PORT', (int)(getenv('SMTP_PORT') ?: 587));
define('SMTP_USERNAME', getenv('SMTP_USERNAME') ?: '');
define('SMTP_PASSWORD', getenv('SMTP_PASSWORD') ?: '');
define('SMTP_SECURE', getenv('SMTP_SECURE') ?: 'tls');
define('MAIL_FROM_EMAIL', getenv('MAIL_FROM_EMAIL') ?: (SMTP_USERNAME ?: 'no-reply@localhost'));
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: 'AMA Computer College OJT Department');
define('SYSTEM_URL', rtrim(getenv('SYSTEM_URL') ?: 'https://amapracticummanagementsystem.xo.je/', '/') . '/');
